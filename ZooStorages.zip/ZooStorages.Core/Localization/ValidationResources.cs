﻿using Microsoft.Extensions.Localization;
using ZooStorages.Core;
using ZooStorages.Core.Errors;

namespace ZooStorages.Domain.Localization
{
	public class Validations
	{}
}
