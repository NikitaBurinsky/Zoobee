﻿namespace ZooStorages.Application.Interfaces.Services
{
	public interface IGeoService
	{



	}
}
