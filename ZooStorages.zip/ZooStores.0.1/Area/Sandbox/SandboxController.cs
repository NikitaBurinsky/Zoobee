﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Localization;
using ZooStorages.Core.Errors;
using ZooStorages.Domain.Localization;

namespace ZooStores.Web.Area.Testcase
{
	[Route("sandbox")]
	public class SandboxController : Controller
	{
		
	}
}
