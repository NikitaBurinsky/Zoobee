﻿namespace ZooStorages.Core.Errors
{
	public class Errors
    {
    }
}
