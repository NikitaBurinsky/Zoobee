﻿using Microsoft.AspNetCore.Mvc;

namespace ZooStores.Web.Area.Admin.Products.Selling_Slots
{
	[Route("admin/products/selling/self-pickup")]
	[ApiController]
	public class SelfPickupOptionsController : ControllerBase
	{
	
	}
}
